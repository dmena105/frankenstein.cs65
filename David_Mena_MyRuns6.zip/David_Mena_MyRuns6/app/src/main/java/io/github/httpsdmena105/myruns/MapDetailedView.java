package io.github.httpsdmena105.myruns;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.location.Location;
import android.nfc.tech.TagTechnology;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.sql.Array;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.List;

//This Class is called the when the Marker Icon is clicked on an elidgle Entry Item
public class MapDetailedView extends FragmentActivity implements OnMapReadyCallback {
    final static String TAG = "TES123";

    private GoogleMap mMap;
    //This is the string that holds the array transformed in to a String passed to the Intent
    String mapArray;

    //Polyline
    Polyline polyline;
    PolylineOptions rectOptions;

    //Variables to Display
    String Activity;
    Double avgSpeed;
    Double Distance;
    int Duration;
    Double Climb;
    String Calories;

    //To know what is the current prefrence state
    public static String MilesOrKilometers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_detailed_view);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        //Get the prefrence for Miles or Kilometers
        SharedPreferences SP = PreferenceManager.getDefaultSharedPreferences(this);
        MilesOrKilometers = SP.getString("list_preference", "Miles");

        //This string is used becuase we need to get the Duration with out the indicator
        //of mins or secs
        String tempDura;
        //Assign all the variables passed to the intent
        mapArray = getIntent().getStringExtra("mapArray");
        Activity = getIntent().getStringExtra("type");
        Calories = getIntent().getStringExtra("calories");
        tempDura = getIntent().getStringExtra("duration");
        Distance = Double.parseDouble(getIntent().getStringExtra("distance"));
        //Set to seconds if duration is in Minutes
        if(tempDura.substring(tempDura.length() - 4).equals("mins")){
            Duration = Integer.parseInt(tempDura.substring(0, tempDura.length() - 4)) * 60;
        }
        //Set to number if it is already in seconds
        else {
            Duration = Integer.parseInt(tempDura.substring(0, tempDura.length() - 4));
        }
        //find the average speed
        //by doing overall distance over overall time
        avgSpeed = (Distance / Duration) / .00062137;
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        //The first and last marker
        //beginning and end
        Double lat;
        Double lng;
        Double LastMarkerLat;
        Double LastMarkerLng;
        //set the array string into a List
        List<String> CoordinateList = Arrays.asList(mapArray.split(","));
        lat = Double.parseDouble(CoordinateList.get(0));
        lng = Double.parseDouble(CoordinateList.get(1));
        LatLng First_Marker = new LatLng(lat, lng);
        //add the first marker
        mMap.addMarker(new MarkerOptions().position(First_Marker).title("First Marker").
                icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
        rectOptions = new PolylineOptions().add(First_Marker);
        //loop through the middle points and link them with a polyine
        Double insideLat, insideLng;
        for(int i = 2; i < CoordinateList.size() - 2; i++){
            insideLat = Double.parseDouble(CoordinateList.get(i));
            insideLng = Double.parseDouble(CoordinateList.get(i + 1));
            LatLng LineMarker = new LatLng(insideLat, insideLng);


            if(polyline != null){
                polyline.remove();
                polyline = null;
            }

            //This should draw the line between all the points
            rectOptions.add(LineMarker);
            rectOptions.color(Color.RED);
            polyline = mMap.addPolyline(rectOptions);

            i = i + 1;
        }
        //add the last marker
        LastMarkerLat = Double.parseDouble(CoordinateList.get(CoordinateList.size() - 2));
        LastMarkerLng = Double.parseDouble(CoordinateList.get(CoordinateList.size() - 1));
        LatLng Last_Marker = new LatLng(LastMarkerLat, LastMarkerLng);

        mMap.addMarker(new MarkerOptions().position(Last_Marker).title("Final Marker").
                icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));

        if(polyline != null){
            polyline.remove();
            polyline = null;
        }

        //This should draw the line between all the points
        rectOptions.add(Last_Marker);
        rectOptions.color(Color.RED);
        polyline = mMap.addPolyline(rectOptions);

        // Add a marker in Sydney and move the camera
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(First_Marker, 17));
        Location l = new Location("");
        l.setLongitude(LastMarkerLng);
        l.setLatitude(LastMarkerLat);
        //find the climb based on the last marker
        Climb = l.getAltitude();
        setTextView();
    }

    @SuppressLint("SetTextI18n")
    public void setTextView(){
        TextView textView = (TextView) findViewById(R.id.Detailed_Map_Text_View);
        DecimalFormat df = new DecimalFormat("#.##");
        //Set the Text View for the User to See while Using the Map
        if(MilesOrKilometers.equals("Kilometers")){
            Distance = Distance / 0.62137;

            textView.setText("Type: " + Activity + "\n"
                    //Speed is Originally in Meters/Second
                    + "Avg Speed: " + df.format(avgSpeed * 1.6) + " Kilometers/Hour\n"
                    //Climb is in Meters
                    + "Climb: " + df.format(Climb * 1.6)  + " Kilometers\n"
                    + "Calorie: " + Calories +"\n"
                    //Originally in Meters
                    + "Distance: " + df.format(Distance) + " Kilometers");
        }
        else {
            textView.setText("Type: " + Activity + "\n"
                    //Speed is Originally in Meters/Second
                    + "Avg Speed: " + df.format(avgSpeed) + " Miles/Hour\n"
                    //Climb is in Meters
                    + "Climb: " + df.format(Climb) + " Miles\n"
                    + "Calorie: " + Calories +"\n"
                    //Originally in Meters
                    + "Distance: " + Distance + " Miles");

        }
    }
    //go back to not map view
    public void onBackClick(View v){
        finish();
    }

}
