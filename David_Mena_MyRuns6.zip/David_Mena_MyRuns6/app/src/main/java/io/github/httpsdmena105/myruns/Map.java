package io.github.httpsdmena105.myruns;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Map extends FragmentActivity implements OnMapReadyCallback, ServiceConnection{
    final static String TAG = "TES123";

    private GoogleMap mMap;
    public Marker currentMarker;
    public Marker startMarker;
    private static final int PERMISSION_REQUEST_CODE = 1;
    private boolean firstNewGPSMarker;

    //Service Variables
    boolean isBound = false;
    private ServiceConnection mConnection = this;
    private Messenger mServiceMessenger = null;

    //Polyline
    Polyline polyline;
    PolylineOptions rectOptions;

    //TextView Variables
    public double Distance = 0;
    public double Speed = 0;
    public double avgSpeed = 0;
    public int Duration = 0;
    public double Calories = 0;
    public double Climb = 0;
    public ArrayList<Double> LatAndLng = new ArrayList<Double>();

    //Excersice Entry, this is where all the data is written to
    private ExcersiceEntry_DataSource dataSource = new ExcersiceEntry_DataSource(this);
    private Exersice_Entry entry = new Exersice_Entry();

    //String to know which Units the user want to see the data on
    //Gets initialized onCreate
    public static String MilesOrKilometers;

    //Json Item that holds all the lat and lngs and is evetually used by onSaveInstance
    //and it is also saved as a string on the DataBase
    ToJson json = new ToJson();
    //This map array is used to temporally hold the json element in String form
    private String mapArray;
    //this is used to determine if a boot is triggered by an orientation change
    private boolean fromSavedInstance = false;

    //Arrays and other variables related to Inputtype and Acticity
    //Activity Items
    //Used to read based on the position passed to the intent
    private String[] activityList = new String[] {
            "Running", "Walking", "Standing",
            "Cycling", "Hiking", "Downhill Skiing",
            "Cross-Country Skiing", "Snowboarding",
            "Skating", "Swimming", "Mountain Biking",
            "Wheelchair", "Elliptical", "Other"
    };
    private String Activity;

    //Input Type
    //Used to read based on the position passed to the intent
    private String[] inputList = new String[]{
            "Manual Entry", "GPS", "Automatic"
    };
    private String Inputype;

    //Interger Array used to keep track of how many instances of each activity sensed
    //is returned
    int[] activityCounter;

    //Message from ServiceHandler
    private final Messenger mMessager = new Messenger(new IncomingMessageHandler());
    private class IncomingMessageHandler extends Handler{
        //This handles all the info sent by the service and
        //assigns it to variables here
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                //All of these massages are getting sent here when the location is updated, and
                //the location listener is implement in the Service
                case MapService.MSG_SET_LATLNG_VALUE:
                    //Gets the lat and lng and updates the map accordingly
                    Double lat = msg.getData().getDouble("lat");
                    Double lng = msg.getData().getDouble("lng");
                    Distance = msg.getData().getDouble("distance");
                    Speed = msg.getData().getDouble("speed");
                    avgSpeed = msg.getData().getDouble("averageSpeed");
                    Duration = msg.getData().getInt("duration");
                    Calories = msg.getData().getDouble("calories");
                    Climb = msg.getData().getDouble("altitude");
                    updateWithNewLocation(lat, lng);
                    break;
                //This is the message that the service calls once when it notices a
                //sensor change
                case MapService.MSG_SET_ACTIVITY:
                    int index = msg.getData().getInt("activity");
                    //Increase the count for that index
                    activityCounter[index]++;
                    setNewActivity();
                default:
                    super.handleMessage(msg);
            }
        }
    }

    //Update the activity if necessary and then update the display
    public void setNewActivity(){
        if((activityCounter[0] > activityCounter[1]) &&
                (activityCounter[0] > activityCounter[2])){
            Activity = "Standing";
        }
        else if((activityCounter[1] > activityCounter[0]) &&
                (activityCounter[1] > activityCounter[2])){
            Activity = "Walking";
        }
        else if((activityCounter[2] > activityCounter[0]) &&
                (activityCounter[2] > activityCounter[1])){
            Activity = "Running";
        }
        setTextViewItems();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        //Find out what is the prefered Units
        SharedPreferences SP = PreferenceManager.getDefaultSharedPreferences(this);
        MilesOrKilometers = SP.getString("list_preference", "Miles");

        //ArrayList of doubles to hold all the lat and lngs
        json.array = new ArrayList<Double>();

        //Get info from Intent
        Intent intent = getIntent();
        //Position from the Arrays found in Array.xml that dertermine Activity and Input type
        int input = intent.getIntExtra("input", 0);
        int activity = intent.getIntExtra("activity", 0);
        Activity = activityList[activity];
        Inputype = inputList[input];
        //Add the input type to the excersice entry
        entry.setInputType(Inputype);
        //If the user chose Automatic, then iniliaze the array
        //and make everthing zero
        if(Inputype.equals("Automatic")){
            activityCounter = new int[3];
            activityCounter[0] = 0;
            activityCounter[1] = 0;
            activityCounter[2] = 0;
            Activity = "Waiting for Sensor Input";
        }


        if(savedInstanceState != null){
            //Get the Array in String From instate
            mapArray = savedInstanceState.getString("array");
            //Check the the string isgreater than 12 because that is when the Array
            //Actually has lat and lngs
            if(mapArray.length() > 12) {
                //Cut the brackets off the Array
                mapArray = mapArray.substring(10, mapArray.length() - 2);
                //Set the CSV into a List
                List<String> CoordinateList = Arrays.asList(mapArray.split(","));
                //Loop through the list and add every lat and lng into the Json Array
                //which is empty becase of the reboot
                for (int i = 0; i < CoordinateList.size(); i++) {
                    json.array.add(Double.parseDouble(CoordinateList.get(i)));
                }
                //Let the rest of the Activity know that is coming from savedInstance
                fromSavedInstance = true;
            }
            //Load the previous counter for the Activity Array Counter
            if(Inputype.equals("Automatic")){
                activityCounter[0] = savedInstanceState.getInt("standing");
                activityCounter[1] = savedInstanceState.getInt("walking");
                activityCounter[2] = savedInstanceState.getInt("running");
            }
        }

        //this is start the notifications
        startService(new Intent(this, MapService.class));
        //Start the binding
        doBindService();
        //this means the first Marker has been put down
        firstNewGPSMarker = true;
        //this is to check binding
        isBound = false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //End the MapService which tracks Location
        stopService(new Intent(this, MapService.class));
        try{
            //Send Message to the Service Letting it know it is a screen rotation
            //or ending the program
            Message msg = Message.obtain(null, MapService.MSG_UNREGISTER_CLIENT);
            msg.replyTo = mMessager;
            mServiceMessenger.send(msg);
        }catch (Throwable t){
            Log.e(TAG, "MAP: OnDestroy, failed to closed");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //Load the array into a string, and save it
        outState.putString("array", new Gson().toJson(json));
        if(Inputype.equals("Automatic")) {
            outState.putInt("standing", activityCounter[0]);
            outState.putInt("walking", activityCounter[1]);
            outState.putInt("running", activityCounter[2]);
        }
    }

    //Bind to the service
    private void doBindService(){
        bindService(new Intent(this, MapService.class), mConnection,
                Context.BIND_AUTO_CREATE);
        isBound = true;
    }
    //Only called by onCancel and onDestroy
    //No need to check if the bind service
    private void doUnbindService(){
        if(isBound){
            if(mServiceMessenger != null){
                try {
                    Message msg = Message.obtain(null, MapService.MSG_UNREGISTER_CLIENT);
                    msg.replyTo = mMessager;
                    mServiceMessenger.send(msg);
                }catch (RemoteException e){

                }
            }
        }
        unbindService(mConnection);
        isBound = false;
    }

    @Override
    public void onServiceConnected(ComponentName name, IBinder service){
        mServiceMessenger = new Messenger(service);
        try{
            Message msg = Message.obtain(null, MapService.MSG_REGISTER_CLIENT);
            msg.replyTo = mMessager;
            Bundle bundle = new Bundle();
            if(Inputype.equals("Automatic")){
                bundle.putInt("gps/auto", 0);
            }
            else {
                bundle.putInt("gps/auto", 1);
            }
            msg.setData(bundle);
            mServiceMessenger.send(msg);
        }catch (RemoteException e){}

    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        mServiceMessenger = null;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        //Check Permissions
        if (!checkPermission()) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSION_REQUEST_CODE);
        }
        //If if we booting from an orientation then follow this class
        else if(fromSavedInstance){
            comingFromSaveInstance();
        }
        //First time
        else {
            upDateMap();

        }

    }

    //This is the code that gets Called to load the data from the String that is actually the array
    //of all the lats and lng saved by the onSaveInstanceState
    //This Code is very similar to that found in MapDetailedView
    public void comingFromSaveInstance(){
        //Variables from the end and beginnign marker
        Double lat;
        Double lng;
        Double LastMarkerLat;
        Double LastMarkerLng;

        //Make the mapArray a Coordinate list
        List<String> CoordinateList = Arrays.asList(mapArray.split(","));
        //get the first location
        lat = Double.parseDouble(CoordinateList.get(0));
        lng = Double.parseDouble(CoordinateList.get(1));
        LatLng First_Marker = new LatLng(lat, lng);
        //make the starter marker the first location
        startMarker = mMap.addMarker(new MarkerOptions().position(First_Marker).title("First Marker").
                icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
        //Start conection all the points
        rectOptions = new PolylineOptions().add(First_Marker);

        //loop through all the inbetween points and map them
        Double insideLat, insideLng;
        for(int i = 2; i < CoordinateList.size() - 2; i++){
            insideLat = Double.parseDouble(CoordinateList.get(i));
            insideLng = Double.parseDouble(CoordinateList.get(i + 1));
            LatLng LineMarker = new LatLng(insideLat, insideLng);

            if(polyline != null){
                polyline.remove();
                polyline = null;
            }

            //This should draw the line between all the points
            rectOptions.add(LineMarker);
            rectOptions.color(Color.RED);
            polyline = mMap.addPolyline(rectOptions);

            i = i + 1;
        }

        //Get the most current location on the StringArray
        LastMarkerLat = Double.parseDouble(CoordinateList.get(CoordinateList.size() - 2));
        LastMarkerLng = Double.parseDouble(CoordinateList.get(CoordinateList.size() - 1));
        LatLng Last_Marker = new LatLng(LastMarkerLat, LastMarkerLng);
        //Map it as the current Location
        currentMarker = mMap.addMarker(new MarkerOptions().position(Last_Marker).title("Final Marker").
                icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));

        if(polyline != null){
            polyline.remove();
            polyline = null;
        }

        //This should draw the line between all the points
        rectOptions.add(Last_Marker);
        rectOptions.color(Color.RED);
        polyline = mMap.addPolyline(rectOptions);

        firstNewGPSMarker = false;

        // Add a marker in Sydney and move the camera
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(First_Marker, 17));
        //Calls on update map to set the list view
        upDateMap();
    }

    @SuppressLint({"MissingPermission", "SetTextI18n"})
    private void upDateMap(){
        LocationManager locationManager;
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        //Locate the text View
        TextView textView = (TextView) findViewById(R.id.GPS_Text_View);

        //Set the Critiria for the location service
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        //This Might Change to get the AVG speed and speed
        criteria.setAltitudeRequired(true);
        criteria.setBearingRequired(false);
        criteria.setSpeedRequired(true);
        criteria.setCostAllowed(true);
        //Get the best privder to locate the phone
        String provider = locationManager.getBestProvider(criteria,
                true);

        //give th users something to look at while the gps signal is gotten
        Location location = locationManager.getLastKnownLocation(provider);
        LatLng latLng;
        if(location != null) {
            latLng = fromLocationToLatLng(location);
        }
        else{
            latLng = new LatLng(43.703712, -72.288754);
        }

        //Set the begining marker under the last known location
        if(startMarker == null) {
            startMarker = mMap.addMarker(new MarkerOptions().position(latLng).icon(
                    BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
        }
        //Stree view
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        //Zoom-In
        //17 is the desired zoom level
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17));

        //Only Display this for when the GPS is firs setting up, if it is in between orientation
        //Show the previous Data from savedInstance
        if(fromSavedInstance) {
            textView.setText("Type: " + Activity + "\n"
                    + "No GPS Data Available");
        }
        else {
            setTextViewItems();
        }
    }

    //this is the method that is called by message handler and it updates the current marker and
    //Connects all the points
    @SuppressLint("SetTextI18n")
    private void updateWithNewLocation(Double lat, Double lng){
        LatLng latLng = new LatLng(lat, lng);
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17));

        //This is here because the previous marker is based on the last known location,
        //so we dont want to star updating based on that, so we need to update the "First Marker"
        //To where the user is right now.
        if(firstNewGPSMarker){
            startMarker.remove();
            startMarker = mMap.addMarker(new MarkerOptions().position(latLng).icon(
                    BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
            firstNewGPSMarker = false;
            rectOptions = new PolylineOptions().add(latLng);
        }

        if(polyline != null){
            polyline.remove();
            polyline = null;
        }

        //This should draw the line between all the points
        rectOptions.add(latLng);
        rectOptions.color(Color.RED);
        polyline = mMap.addPolyline(rectOptions);

        if(currentMarker!=null)
            currentMarker.remove();

        //Adds a Marker at the LatLng
        currentMarker = mMap.addMarker(new MarkerOptions().position(latLng).icon(
                BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));

        //Display the setView Items
        setTextViewItems();
        //THIS IS VERY IMPORTANT BECAUSE IT ADD THE LAT AND LNG TO THE JSON ARRAY
        json.array.add(lat);
        json.array.add(lng);
    }

    @SuppressLint("SetTextI18n")
    public void setTextViewItems(){
        TextView textView = (TextView) findViewById(R.id.GPS_Text_View);

        DecimalFormat df = new DecimalFormat("#.##");
        //Set the Text View for the User to See while Using the Map
        if(MilesOrKilometers.equals("Kilometers")){
            textView.setText("Type: " + Activity + "\n"
                    //Speed is Originally in Meters/Second
                    + "Avg Speed: " + df.format(avgSpeed) + " Kilometers/Hour\n"
                    + "Cur Speed: " + df.format(Speed) + " Kilometers/Hour\n"
                    //Climb is in Meters
                    + "Climb: " + df.format(Climb * 0.001) + " Kilometers\n"
                    + "Calorie: " + df.format(Calories) +"\n"
                    //Originally in Meters
                    + "Distance: " + df.format(Distance * 0.001) + " Kilometers");
        }
        else {
            textView.setText("Type: " + Activity + "\n"
                    //Speed is Originally in Meters/Second
                    + "Avg Speed: " + df.format(avgSpeed) + " Miles/Hour\n"
                    + "Cur Speed: " + df.format(Speed) + " Miles/Hour\n"
                    //Climb is in Meters
                    + "Climb: " + df.format(Climb * 0.00062137) + " Miles\n"
                    + "Calorie: " + df.format(Calories) +"\n"
                    //Originally in Meters
                    + "Distance: " + df.format(Distance * 0.00062137) + " Miles");

        }

    }

    //Used by locationUpdate
    @NonNull
    private LatLng fromLocationToLatLng(Location location){
        return  new LatLng(location.getLatitude(), location.getLongitude());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private boolean checkPermission(){
        int result = ContextCompat.checkSelfPermission
                (this, Manifest.permission.ACCESS_FINE_LOCATION);
        //Check permissions are valid
        if(result == PackageManager.PERMISSION_GRANTED){
            return true;
        }
        return false;
    }

    //BUTTON CLICKS
    public void onSaveClicked(View v){
        //Update all the local Entry Items
        updateEntryItem();

        //close the app
        stopService(new Intent(this, MapService.class));
        try{
            //Send Message to the Service Letting it know it is a screen rotation
            //or ending the program
            Message msg = Message.obtain(null, MapService.MSG_UNREGISTER_CLIENT);
            msg.replyTo = mMessager;
            mServiceMessenger.send(msg);
        }catch (Throwable t){
            Log.e(TAG, "MAP: OnDestroy, failed to closed");
        }

        //Save everything to the data base
        new Map.WritingTask().execute();
        //Make a toast that says saved
        Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_SHORT).show();
        //finish
        finish();
    }

    //This function is called ONLY when the save button is clicked and it writes to
    //the local entry items before the Async Task is called to write on the Database
    private void updateEntryItem() {
        //Make the ToJason item into a string using Gson
        Gson gson = new Gson();
        String mapArray = gson.toJson(json);
        DecimalFormat df = new DecimalFormat("#.##");
        //Change Seconds to Minutes
        if(Duration >= 60){
            Duration = Duration / 60;
            entry.setDuration(Duration + "mins");
        }
        else {
            entry.setDuration(Duration + "secs");
        }
        //Set Every Variable
        entry.setDistance(df.format(Distance * 0.00062137) + "");
        entry.setCalories(df.format(Calories) + "");
        entry.setMapArray(mapArray);
        entry.setActivityType(Activity);
    }

    public void onCancelClicked(View v){
        //Make a toast that says canceled
        Toast.makeText(getApplicationContext(), "Canceled", Toast.LENGTH_SHORT).show();
        //close the app
        //doUnbindService();
        stopService(new Intent(this, MapService.class));
        try{
            //Send Message to the Service Letting it know it is a screen rotation
            //or ending the program
            Message msg = Message.obtain(null, MapService.MSG_UNREGISTER_CLIENT);
            msg.replyTo = mMessager;
            mServiceMessenger.send(msg);
        }catch (Throwable t){
            Log.e(TAG, "MAP: OnDestroy, failed to closed");
        }
        //close the Activity
        finish();
    }


    //************* ASYNC-TASK for Writing Database **************//
    //This is the class used by Manual Entry
    private class WritingTask extends AsyncTask<Void, Void, Void> {

        // A callback method executed on UI thread on starting the task
        @Override
        protected void onPreExecute() {
            //Starts the Database table
            dataSource.open();
        }

        @Override
        protected Void doInBackground(Void... params) {
            //Load the data from the entry item we we've created.
            dataSource.createEntry(entry.getDate(), entry.getTime(),
                    entry.getDuration(), entry.getDistance(), entry.getCalories(), entry.getHeartRate(),
                    entry.getComment(), entry.getInputType(), entry.getActivityType(), entry.getMapArray(),
                    entry.getId());

            dataSource.close();
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }

        @Override
        protected void onPostExecute(Void result) {
        }
    }

    //This is the class that holds the Array Json
    public class ToJson {
        @SerializedName("Array")
        public List array;
    }
}
