package io.github.httpsdmena105.myruns;

/**
 *
 * Created by davidmena on 1/12/18.
 *
 */

import android.app.DialogFragment;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.soundcloud.android.crop.Crop;


/*
***Disclaimer****
Some of the format and code was inspired from DemoTestCamera, Camera
and Layouts apks, as well as the sample code offered in the CS65 Website

Myruns1 - Profile sections
By David Mena
This App lets a User set up a profile with basic information and a photo
The use has the power to save the information or cancel it
*/

public class Profile extends AppCompatActivity {
    //Log.d(TAG, "Message");
    private static final String TAG = "RNS1";

    //Set up variables
    private ImageView imageView;
    private Uri ImgUri;
    private String imgFileName = "DM.png";
    private static final String URI_SAVE_KEY = "saved_uri";
    public static final int CAMERA_CODE = 0;
    public static final int PICK_IMAGE = 1;
    //For LogOut Button
    Toolbar toolbar;
    //Used for signing out
    private FirebaseAuth mFirebaseAuth;


    private static ExcersiceEntry_DataSource dataSource;
    public static List<Exersice_Entry> listOfAllEntries; //Has all the preloaded entries

    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);
        //cast imageView to the right image in the XML
        imageView = (ImageView)findViewById(R.id.profileImage);

        toolbar = (Toolbar) findViewById(R.id.toolbarForProfile);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Profile");

        mFirebaseAuth = FirebaseAuth.getInstance();

        dataSource = new ExcersiceEntry_DataSource(this);
        context = getApplicationContext();

        //Load the user data
        loadUserData();


        //If there is a savedInstance, load the photo
        if (savedInstanceState != null){
            //Set the URI to the uri from the save state
            ImgUri = savedInstanceState.getParcelable(URI_SAVE_KEY);
            //Set the imageView with the new URI
            imageView.setImageURI(ImgUri);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_profile, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //Listen to for the delete button
        if (item.getItemId() == R.id.action_logout) {
            //Logs the User Out
            mFirebaseAuth.signOut();
            //This Async Task Deletes all the Information from
            //the local machine while the user is logged out
            new DeleteLocalDataBase().execute();
            //Opens the log in Page
            loadLogInView();
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadLogInView() {
        Intent intent = new Intent(this, LogInActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    //Used for when the app restarts/resumes
    @Override
    protected void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
        //Set the outstate
        outState.putParcelable(URI_SAVE_KEY, ImgUri);

    }

    //Handle Actions when returning from certain activities
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(resultCode != RESULT_OK){
            return;
        }
        //After returning from the camera, begin cropping
        if(requestCode == CAMERA_CODE){
            //Set a temporal URI to hold the photo
            Uri destination = Uri.fromFile(new File(getCacheDir(), "cropped"));
            Crop.of(ImgUri, destination).asSquare().start(this);


        }
        //For the when the user uses the pick image out of gallery
        else if (requestCode == PICK_IMAGE){
            Uri destination = Uri.fromFile(new File(getCacheDir(), "cropped"));
            Crop.of(data.getData(), destination).asSquare().start(this);
        }

        //after returning from cropping place the photo in the image view
        else if (requestCode == Crop.REQUEST_CROP){
            //Get the cropped image
            Uri croppedImage = Crop.getOutput(data);
            //Set the image view
            imageView.setImageURI(null);
            imageView.setImageURI(croppedImage);

            ImgUri = croppedImage;


        }
    }

    //Clicking on change photo
    public void onChangePhotoClicked(View view){
        //Changing the profile image, show the dialog to the user
        //The user can chose to take photo or pick from lib
        displayDialog(PhotoDialogFragment.DIALOG_ID_PHOTO_PICKER);
    }


    // ****************** PHOTO PICKER FUNCTIONS **************** //

    public void displayDialog(int id) {
        DialogFragment fragment = PhotoDialogFragment.newInstance(id);
        fragment.show(getFragmentManager(), getString(R.string.dialog_fragment_photo_picker));
    }

    public void onPhotoPickerSelected(int item){
        Intent intent;

        switch (item) {
            case PhotoDialogFragment.ID_FROM_CAMERA:
                intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                //Get the set the URI to the URI return
                ContentValues values = new ContentValues(1);
                values.put(MediaStore.Images.Media.MIME_TYPE, "images");
                ImgUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);


                //Send the uri to the activity
                intent.putExtra(MediaStore.EXTRA_OUTPUT, ImgUri);
                intent.putExtra("return-data", true);

                //Open the camera
                try{
                    startActivityForResult(intent, CAMERA_CODE);
                }
                //catch the error if the camera can't open
                catch (ActivityNotFoundException e){
                    e.printStackTrace();
                }

                break;

            //HOW DO I GET THE IMAGE AFTER PICKING IT
            case PhotoDialogFragment.ID_FROM_GALLERY:
                intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);

                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
                break;

            default:
                return;
        }
    }


    // ****************** LOAD AND SAVING DATA RELATED FUNCTIONS ************* //

    //When save is clicked
    public void onSaveClicked(View v){
        //Call on Saving the Data
        saveUserData();
        //Make a toast that says saved
        Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_SHORT).show();
        //close the app
        finish();
    }

    public void onCancelClicked(View v){
        //Make a toast that says canceled
        Toast.makeText(getApplicationContext(), "Canceled", Toast.LENGTH_SHORT).show();
        //close the app
        finish();
    }

    //load all the saved User info
    private void loadUserData(){
        //Function that loads the photo
        loadPhoto();
        //If no data is found for each item then the "hint"
        //Will be shown
        Log.d(TAG, "Loading User Data");

        //key related to this bundle of information
        String mKey = getString(R.string.preference_name);
        SharedPreferences mPrefs = getSharedPreferences(mKey, MODE_PRIVATE);

        //Load User Name
        mKey = getString(R.string.preference_key_profile_name);
        String mValue = mPrefs.getString(mKey,  "");
        ((EditText) findViewById(R.id.editName)).setText(mValue);

        //Load User Email
        mKey = getString(R.string.preference_key_profile_email);
        String mValue1 = mPrefs.getString(mKey, "");
        ((EditText) findViewById(R.id.editEmail)).setText(mValue1);

        //Load User Phone
        mKey = getString(R.string.preference_key_profile_phone_number);
        String mValue2 = mPrefs.getString(mKey, "");
        ((EditText) findViewById(R.id.editPhone)).setText(mValue2);

        //Load Gender Check Box
        mKey = getString(R.string.preference_key_profile_gender);
        int mIntValue = mPrefs.getInt(mKey, -1);
        if(mIntValue >= 0){ // If the inst one saved before hand
            RadioButton radioBtn = (RadioButton) ((RadioGroup) findViewById(R.id.radioGender))
                    .getChildAt(mIntValue); //Button that should be checked
            radioBtn.setChecked(true); //Check the button
        }

        //Load User Class
        mKey = getString(R.string.preference_key_profile_class);
        String mValue3 = mPrefs.getString(mKey,  "");
        ((EditText) findViewById(R.id.editClass)).setText(mValue3);

        //Load User Major
        mKey = getString(R.string.preference_key_profile_major);
        String mValue4 = mPrefs.getString(mKey, "");
        ((EditText) findViewById(R.id.editMajor)).setText(mValue4);

    }

    //Load photo from the external files
    public void loadPhoto(){
        //Try to load the photo from the files
        try{
            //input from the image file
            FileInputStream in = openFileInput(imgFileName);
            //Make a bitmap from the file
            Bitmap bmap = BitmapFactory.decodeStream(in);
            //Set the image view
            imageView.setImageBitmap(bmap);
            //Free Memory
            in.close();
        }
        //If the photo doesn't exist then load the default pic
        catch (IOException e){
            imageView.setImageResource(R.drawable.default_profile);
        }
    }

    //Save Data ***Only used when the save button is pressed****
    public void saveUserData(){
        //Call on a function to save the photo
        savePhoto();

        //Let the LOG know the data is saving
        Log.d(TAG, "Saving User Data");
        //Commit the changes to a compressed file

        //Key for this bundle of info
        String mKey = getString(R.string.preference_name);
        SharedPreferences mPrefs = getSharedPreferences(mKey, MODE_PRIVATE);

        //Start the editor
        SharedPreferences.Editor mEditor = mPrefs.edit();
        mEditor.clear();

        //Save User Name
        mKey = getString(R.string.preference_key_profile_name);
        String mValue = (String) ((EditText) findViewById(R.id.editName)).getText().toString();
        mEditor.putString(mKey, mValue);

        //Save User Email
        mKey = getString(R.string.preference_key_profile_email);
        String mValue1 = (String) ((EditText) findViewById(R.id.editEmail)).getText().toString();
        mEditor.putString(mKey, mValue1);

        //Save User Phone Number
        mKey = getString(R.string.preference_key_profile_phone_number);
        String mValue2 = (String) ((EditText) findViewById(R.id.editPhone)).getText().toString();
        mEditor.putString(mKey, mValue2);

        //Save User Gender Check Box
        mKey = getString(R.string.preference_key_profile_gender);
        RadioGroup mRadioGroup = (RadioGroup) findViewById(R.id.radioGender);
        int mIntValue = mRadioGroup.indexOfChild(findViewById(mRadioGroup.getCheckedRadioButtonId()));
        mEditor.putInt(mKey, mIntValue);

        //Save User Class
        mKey = getString(R.string.preference_key_profile_class);
        String mValue3 = (String) ((EditText) findViewById(R.id.editClass)).getText().toString();
        mEditor.putString(mKey, mValue3);

        //Save User Major
        mKey = getString(R.string.preference_key_profile_major);
        String mValue4 = (String) ((EditText) findViewById(R.id.editMajor)).getText().toString();
        mEditor.putString(mKey, mValue4);

        //Commit all Changes
        mEditor.commit();
    }

    //Function to save the photo in the exteral storage
    public void savePhoto(){
        //build the Image View bitmap
        imageView.buildDrawingCache();
        //Get the bitmap from image view
        Bitmap bmap = imageView.getDrawingCache();
        //try to save the photo on the external drive
        try{
            //Load based on the filename
            FileOutputStream out = openFileOutput(imgFileName, MODE_PRIVATE);
            //Compress the bitmap
            bmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.flush();
            //Free the memory
            out.close();
        }
        //Send error
        catch (IOException ioe){
            ioe.printStackTrace();
        }
    }


    private class DeleteLocalDataBase extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            dataSource.open();
            listOfAllEntries = dataSource.getAllEntries();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            for(int i = 0; i < listOfAllEntries.size(); i++){
                Exersice_Entry entry = listOfAllEntries.get(i);
                dataSource.deleteEntry(entry);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            dataSource.close();
            context.deleteDatabase(MySQLiteHelper.DATABASE_NAME);
        }
    }

}