package io.github.httpsdmena105.myruns;

import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;


/**
 * Created by davidmena on 1/12/18.
 * This Fragment is spefically used to house the settings
 * for the app. This Fragment is static since it is coded in the
 * XML file named fragment settings
 */

public class Fragment_settings extends PreferenceFragment {
    final private static String TAG = "TES123";

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        //Load the preferences from an XML resource
        addPreferencesFromResource(R.xml.preference);

        //This is the listener for whenever the User changes the settings in
        //the preference menu for that sepecific Setting
        Preference list = (Preference) findPreference("list_preference");
        list.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                //Gets the string that the setting was changed to
                //Either Miles or Kilometers
                String mok = (String) newValue;
                //Updates the Fragment history display by calling
                //On the Async task responsible for Reading.
                Fragment_history.upDateMetrics(mok);
                return true;
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

}
