package io.github.httpsdmena105.myruns;

import android.app.Fragment;
import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.Tag;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.*;
import java.util.Map;

/**
 *
 * Created by davidmena on 1/12/18.
 *
 * This Fragment is responsible for Displaying the Database in the second tab of the app.
 * This Fragment also Starts the DataBase and uses Async to load the Data.
 * If the user clicks on any of the DataBase items it will call the EntryDetailedView Activity.
 *
 */

public class Fragment_history extends Fragment {
    final static String TAG = "TES123";

    //Variables that are only used in this class
    private static ExcersiceEntry_DataSource dataSource;
    private static ArrayList<HashMap<String, String>> finalList = new ArrayList<HashMap<String, String>>();
    private static View v;

    //This variable is also used by Entry_detailed_view
    public static List<Exersice_Entry> listOfAllEntries; //Has all the preloaded entries

    //This String Holds the Value of the Settings Preference for the Users preference of
    //miles or Kilometers; it affects how the Fragment Displays the Data.
    public static String MilesOrKilometers;

    //This is the variables for Firebase
    public static FirebaseAuth mFirebaseAuth;
    public static FirebaseUser mFirebaseUser;
    public static DatabaseReference mDatabase;
    public static String mUserId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        v = inflater.inflate(R.layout.fragment_history, container, false);
        //This is used to get the value of weather the user wants to see the infor in miles
        //or Kilometers. The default is Miles.
        SharedPreferences SP = PreferenceManager.getDefaultSharedPreferences(getActivity());
        MilesOrKilometers = SP.getString("list_preference", "Miles");

        //Initialize FireBase Variables
        mFirebaseAuth = FirebaseAuth.getInstance();
        mFirebaseUser = mFirebaseAuth.getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        mUserId = mFirebaseUser.getUid();

        //Initializes the DataSource item
        dataSource = new ExcersiceEntry_DataSource(getActivity());

        //Find the ListView in the XML
        ListView listView = (ListView)v.findViewById(R.id.listView);

        //The Simple Adapter reads the Final List which is an Array List of HashMaps
        //And displays the Data based on the Array, this is used to display two different
        //Lines, when we open the app, FINAL LIST WILL BE EMPTY, See Resume to load the data.
        SimpleAdapter SA = new SimpleAdapter(getActivity(), finalList, R.layout.two_lines,
                new String[]{"line1", "line2"}, new int[]{R.id.line_a, R.id.line_b});

        //The the adapter to the listview
        listView.setAdapter(SA);

        //Click Listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getActivity(), Entry_detailed_view.class);
                //Sends which Item was clicked on the Display AKA the item in
                //ListOfAllEntries and it also passes the value of Miles or Kilometers.
                intent.putExtra("Position", position);
                intent.putExtra("MorK", MilesOrKilometers);
                startActivity(intent);
            }
        });

        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        dataSource.open();
        //Calls Async to Read the DataBase in the Background
        new ReadingTask().execute();
    }

    @Override
    public void onPause() {
        super.onPause();
        dataSource.close();
    }

    //This is only called on by Fragment Settings when the User changes b/w
    //Kilometers or Miles
    public static void upDateMetrics(String MoK){
        //Update value of Miles or Kilometers
        if(MilesOrKilometers.equals(MoK)){
            //If the User chooses something that is already selected
            //then do nothing
            return;
        }
        //Set the new Metric
        MilesOrKilometers = MoK;
        //Load the database again and update the ListView
        new ReadingTask().execute();
    }

    //This method is used by Entry_Detailed view when an item is deleted
    //and it is also used by the Async Task to update Date the Listview
    public static void upDateListView(){
        ListView listView = (ListView)v.findViewById(R.id.listView);
        SimpleAdapter AD =(SimpleAdapter)listView.getAdapter();
        try {
            AD.notifyDataSetChanged();
        }catch (Throwable e){
            return;
        }
    }

    //This is called by Detailed Entry View after an Item is deleted
    public static void upDateFragment(){
        new ReadingTask().execute();
    }



//************* ASYNC-TASK for ReadingOnCreate **************//

    //There is no communication between the UI and the Async, that's why
    //the parameters are void.
    public static class ReadingTask extends AsyncTask<Void, Void, Void> {

        // A callback method executed on UI thread on starting the task
        @Override
        protected void onPreExecute() {
            //get the updated list of Excersice entries from the Database
            listOfAllEntries = dataSource.getAllEntries();
        }

        //Loads the right items in FinalList, based on weather to display in
        //Kilometers or in Miles
        @Override
        protected Void doInBackground(Void... params) {
            //Load from FireBase
            if(listOfAllEntries.size() == 0){
                finalList.clear();
                //Load the local database with items from FireBase
                final DatabaseReference ref = mDatabase.child("Users").child(mUserId).child("runs");
                ref.addListenerForSingleValueEvent(new ValueEventListener(){
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for(DataSnapshot single: dataSnapshot.getChildren()){
                            Map<String,Object> singleRun = (Map<String,Object>) single.getValue();
                            final Exersice_Entry entry = new Exersice_Entry();

                            entry.setId((long) singleRun.get("id"));
                            entry.setInputType((String) singleRun.get("inputType"));
                            entry.setHeartRate((String) singleRun.get("heartRate"));
                            entry.setActivityType((String) singleRun.get("activityType"));
                            entry.setTime((String) singleRun.get("Time"));
                            entry.setDuration((String) singleRun.get("Duration"));
                            entry.setDistance((String) singleRun.get("Distance"));
                            entry.setDate((String) singleRun.get("Date"));
                            entry.setComment((String) singleRun.get("Comment"));
                            entry.setCalories((String) singleRun.get("Calories"));

                            //This is necessary to get the LAT AND LNG
                            DatabaseReference ref1 = ref.child("" + singleRun.get("id")).child("locationLatLngList");
                            ref1.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    if(dataSnapshot.hasChildren()){
                                        int counter = 0;
                                        String array = "{\"Array\":[";
                                        while (dataSnapshot.child(""+counter).hasChildren()){
                                            array = array + (String) dataSnapshot.child(""+counter).child("Latitude").getValue();
                                            array = array + ",";
                                            array = array + (String) dataSnapshot.child(""+counter).child("Longitude").getValue();
                                            array = array + ",";
                                            counter++;
                                        }
                                        array = array.substring(0, array.length() - 1);
                                        array = array + "]}";
                                        entry.setMapArray(array);

                                        dataSource.createEntry(entry.getDate(), entry.getTime(),
                                                entry.getDuration(), entry.getDistance(), entry.getCalories(), entry.getHeartRate(),
                                                entry.getComment(), entry.getInputType(), entry.getActivityType(), entry.getMapArray(),
                                                entry.getId());

                                    }
                                    else {
                                        dataSource.createEntry(entry.getDate(), entry.getTime(),
                                                entry.getDuration(), entry.getDistance(), entry.getCalories(), entry.getHeartRate(),
                                                entry.getComment(), entry.getInputType(), entry.getActivityType(), entry.getMapArray(),
                                                entry.getId());
                                    }

                                    upDateUI();
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {

                                }
                            });

                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });
            }

            //The Database Contains more than Zero Items
            else {
                upDateUI();
            }
            return null;
        }

        private void upDateUI(){
            listOfAllEntries = dataSource.getAllEntries();
            //We clear the final list so the adapter don't duplicate
            //the number of entries. Since we are reloading it.
            finalList.clear();
            HashMap<String, String> item;
            if (MilesOrKilometers.equals("Kilometers")) {
                //To control the number of Decimals after a Double
                DecimalFormat format = new DecimalFormat("#.##");
                for (int i = 0; i < listOfAllEntries.size(); i++) {
                    Exersice_Entry entry = listOfAllEntries.get(i);
                    item = new HashMap<String, String>();
                    //Get the distance in a Double
                    double Distance = Double.parseDouble(entry.getDistance());
                    //Convert Miles to Kilometers
                    Distance = Distance / 0.62137;

                    //Load the items in the correct Format
                    item.put("line1", entry.getInputType() + ": " + entry.getActivityType() + ", " +
                            entry.getTime() + " " + entry.getDate());
                    item.put("line2", format.format(Distance) + " Kilometers, " + entry.getDuration());
                    //Add them to final list
                    finalList.add(item);
                }
            }
            //Load in Miles
            else {
                for (int i = 0; i < listOfAllEntries.size(); i++) {
                    Exersice_Entry entry = listOfAllEntries.get(i);
                    item = new HashMap<String, String>();
                    item.put("line1", entry.getInputType() + ": " + entry.getActivityType() + ", " +
                            entry.getTime() + " " + entry.getDate());
                    item.put("line2", entry.getDistance() + " Miles, " + entry.getDuration());
                    finalList.add(item);
                }
            }
        }


        // A callback method executed on UI thread, invoked by the publishProgress()
        // from doInBackground() method

        // Overrider this handler to post interim updates to the UI thread. This handler receives the set of parameters
        // passed in publishProgress from within doInbackground.
        @Override
        protected void onProgressUpdate(Void... values) {}

        // A callback method executed on UI thread, invoked after the completion of the task

        // When doInbackground has completed, the return value from that method is passed into this event
        // handler.
        @Override
        protected void onPostExecute(Void result) {
            //This Updates the ListView
            upDateListView();
        }
    }
}
