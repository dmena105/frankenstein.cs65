package io.github.httpsdmena105.myruns;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;

/**
 * Created by davidmena on 1/15/18.
 *
 * This is used by the profile in order to let the user
 * pick a photo off their library
 */

public class PhotoDialogFragment extends DialogFragment {

    //ID FOR WHAT THE USER PICKED
    public static final int ID_FROM_CAMERA = 0;
    public static final int ID_FROM_GALLERY = 1;

    //Different dialog ID
    public static final int DIALOG_ID_ERROR = -1;
    public static final int DIALOG_ID_PHOTO_PICKER = 1;

    private static final String ID_KEY = "dialog_id";

    //Sets up a new instance of the dialog fragment
    public static PhotoDialogFragment newInstance(int dialog_id) {
        PhotoDialogFragment frag = new PhotoDialogFragment();
        Bundle args = new Bundle();
        args.putInt(ID_KEY, dialog_id);
        frag.setArguments(args);
        return frag;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        //Loads the argument into an int w/ the ID key
        int dialog_id = getArguments().getInt(ID_KEY);
        //loads the PROFILE activity into a variable
        final Activity parent = getActivity();
        //Set up dialog and what the user clicks on
        switch (dialog_id){
            case DIALOG_ID_PHOTO_PICKER:
                //Picture picker dialog to chose from gallery or camera
                AlertDialog.Builder builder = new AlertDialog.Builder(parent);
                builder.setTitle(R.string.profile_photo_picker_tittle);
                //Set up click listeners, firing intents open camera
                DialogInterface.OnClickListener dlisteners = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ((Profile) parent).onPhotoPickerSelected(which);
                    }
                };
                //Set the item/s to display and create the dialog
                builder.setItems(R.array.profilr_photo_picker_array, dlisteners);
                return builder.create();
            default:
                return null;
        }
    }
}
