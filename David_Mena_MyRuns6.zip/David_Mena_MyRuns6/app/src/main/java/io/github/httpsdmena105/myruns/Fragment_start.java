package io.github.httpsdmena105.myruns;

import android.app.Fragment;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Arrays;
import java.util.List;

/**
        *
 * Created by davidmena on 1/12/18.
 *
 * This Fragment represents the Start Tab on the tab, and hold two input Spinners
 * and a Start and Sync Button
 *
 * The User will be able to Start Tracking, input information, and Sync data to the cloud
 * through this Main Page.
 *
 */

public class Fragment_start extends Fragment {
    final static String TAG = "TES123";

    //These are the variables for Firebase
    private FirebaseAuth mFirebaseAuth;
    private FirebaseUser mFirebaseUser;
    private DatabaseReference mDatabase;
    private String mUserId;

    //These are the variables for the local Variable
    private ExcersiceEntry_DataSource dataSource;
    private List<Exersice_Entry> listOfAllEntries;


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        //Inflate the fragment xml
        View v = inflater.inflate(R.layout.fragment_start, container, false);

        //This is the input type to tell the program how they want to input their info
        final Spinner input = (Spinner)v.findViewById(R.id.spinnerInput);
        //This is the Activity Type to tell the program what activity the user doing this
        final Spinner ActivityType = (Spinner)v.findViewById(R.id.spinnerActivity);

        //Initializes the DataSource item
        dataSource = new ExcersiceEntry_DataSource(getActivity());
        //Initialize all the Firebase variables
        mFirebaseAuth = FirebaseAuth.getInstance();
        mFirebaseUser = mFirebaseAuth.getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        //This button is the start button
        Button b = (Button)v.findViewById(R.id.Button_START);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Depending on what the Input Type is the START button will
                //either open the MAPS or the manual entry class
                // 0 is Manal Entry and 1-2 are GPS and Automatic
                if(input.getSelectedItemPosition() == 0){
                    Intent intent = new Intent(getActivity(), Manual_Entry.class);
                    intent.putExtra("input", input.getSelectedItemPosition());
                    intent.putExtra("activity", ActivityType.getSelectedItemPosition());
                    startActivity(intent);
                }
                else{
                    Intent intent2 = new Intent(getActivity(), Map.class);
                    intent2.putExtra("input", input.getSelectedItemPosition());
                    intent2.putExtra("activity", ActivityType.getSelectedItemPosition());
                    startActivity(intent2);
                }

            }
        });

        //Sync is the button that loads everything into the cloud
        Button Sync = v.findViewById(R.id.Button_SYNC);
        Sync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new PassingToFirebase().execute();
                Toast.makeText(getActivity(), "Data is Syncing", Toast.LENGTH_SHORT).show();
            }
        });
        return v;
    }

    private class PassingToFirebase extends AsyncTask<Void, Void, Void>{
        //This async task is responsible for passing everything into the Firebase
        @Override
        protected void onPreExecute() {
            dataSource.open();
            listOfAllEntries = dataSource.getAllEntries();
            mUserId = mFirebaseUser.getUid();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            //Loop through the items that are currently on the Database
            for(int i = 0; i < listOfAllEntries.size(); i++){
                Exersice_Entry entry = listOfAllEntries.get(i);
                //Create a Database Refrence at that User and at that run
                DatabaseReference tempDatabase = mDatabase.child("Users").child(mUserId).child("runs").child(""+entry.getId());
                //Only go into this loop id the Item come from GPS or Automatic
                //Because those have a MapArray with locations
                if(!entry.getInputType().equals("Manual Entry")){
                    //Create another child
                    DatabaseReference temp2 = tempDatabase.child("locationLatLngList");
                    //Get the array from the entry item
                    String mapArray = entry.getMapArray();
                    //There are elements in the Array
                    //This means that the array is not empty
                    if(mapArray.length() > 12) {
                        //Cut the brackets off the Array
                        mapArray = mapArray.substring(10, mapArray.length() - 2);
                        //Set the CSV into a List
                        List<String> CoordinateList = Arrays.asList(mapArray.split(","));
                        //Loop through the list and add every lat and lng into the Json Array
                        //which is empty becase of the reboot
                        int counter = 0;
                        for (int j = 0; j < CoordinateList.size(); j++) {
                            //Make another child, for each lat and lng item
                            DatabaseReference temp3 = temp2.child(""+counter);
                            temp3.child("Latitude").setValue(CoordinateList.get(j));
                            temp3.child("Longitude").setValue(CoordinateList.get(j + 1));
                            counter++;
                            j++;
                        }
                    }
                    //No Element in the Array
                    else{
                        //This is important so detailed entry view does not try to
                        //re map the trip without any Lat and Lng information
                       temp2.setValue("No GPS information");
                    }
                }
                //Add every other item in the correct Category for each item
                tempDatabase.child("inputType").setValue(entry.getInputType());
                tempDatabase.child("id").setValue(entry.getId());
                tempDatabase.child("heartRate").setValue(entry.getHeartRate());
                tempDatabase.child("Duration").setValue(entry.getDuration());
                tempDatabase.child("Distance").setValue(entry.getDistance());
                tempDatabase.child("Time").setValue(entry.getTime());
                tempDatabase.child("Date").setValue(entry.getDate());
                tempDatabase.child("Comment").setValue(entry.getComment());
                tempDatabase.child("Calories").setValue(entry.getCalories());
                tempDatabase.child("activityType").setValue(entry.getActivityType());

            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            dataSource.close();
        }
    }
}


