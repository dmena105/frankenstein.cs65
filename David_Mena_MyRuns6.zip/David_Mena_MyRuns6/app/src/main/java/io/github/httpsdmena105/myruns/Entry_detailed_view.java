package io.github.httpsdmena105.myruns;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;

/**
 *
 * Created by davidmena on 1/28/18.
 *
 * This is the Activity that opens after the user clicks on
 * an item in the list view found on the Fragment History
 *
 */

public class Entry_detailed_view extends AppCompatActivity {
    final static String TAG = "TES123";
    //Set the varibales realted to the Database
    private Exersice_Entry entry;
    private ExcersiceEntry_DataSource dataSource = new ExcersiceEntry_DataSource(this);
    //This allows to create my own personal toolbar
    //Look in Styles.xml because I am not using the "Regular"
    //Toolbar configuration
    Toolbar toolbar;

    public String GPSorManual;

    //Variables Having to do With FireBase
    private FirebaseAuth mFirebaseAuth;
    private FirebaseUser mFirebaseUser;
    private DatabaseReference mDatabase;
    private String mUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.entry_detailed_view);
        //Open the datasource but only to delete items from the Database
        dataSource.open();
        //Set the tool bar and Inflate it
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("MyRuns");

        //Initialize the Variables
        mFirebaseAuth = FirebaseAuth.getInstance();
        mFirebaseUser = mFirebaseAuth.getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        mUserId = mFirebaseUser.getUid();

        //Load the information found on the intent
        Intent intent = getIntent();
        //what entry was clicked on
        int position = intent.getIntExtra("Position", 0);
        //Miles or Kilometers
        String MorK = intent.getStringExtra("MorK");

        //The correct entry based on which item the user wants to seee
        entry = Fragment_history.listOfAllEntries.get(position);
        GPSorManual = entry.getInputType();

        //Get all the EditText views
        EditText InputType = (EditText) findViewById(R.id.textInputType);
        EditText ActivityType = (EditText) findViewById(R.id.textActivityType);
        EditText DateAndTime = (EditText) findViewById(R.id.textDateAndTime);
        EditText Duration = (EditText) findViewById(R.id.textDuration);
        EditText Distance = (EditText) findViewById(R.id.textDistance);
        EditText Calories = (EditText) findViewById(R.id.textCalories);
        EditText HeartRate = (EditText) findViewById(R.id.textHeartRate);

        //Combination of Date and time
        String DateTime = entry.getDate() + " " + entry.getTime();

        //Set all the Text from the correct entry
        InputType.setText(entry.getInputType(), EditText.BufferType.NORMAL);
        ActivityType.setText(entry.getActivityType(), EditText.BufferType.NORMAL);
        DateAndTime.setText(DateTime, EditText.BufferType.NORMAL);
        Duration.setText(entry.getDuration(), EditText.BufferType.NORMAL);
        Calories.setText(entry.getCalories(), EditText.BufferType.NORMAL);
        HeartRate.setText(entry.getHeartRate(), EditText.BufferType.NORMAL);

        //Set Distance Accordingly based on weather is Miles or Kilometers
        if(MorK.equals("Kilometers")){
            DecimalFormat format = new DecimalFormat("#.##");
            Double preDistance = Double.parseDouble(entry.getDistance());
            Double Dist = preDistance/0.62137;
            String distance = format.format(Dist) + " Kilometers";
            Distance.setText(distance, EditText.BufferType.NORMAL);
        }
        else {
            String distance = entry.getDistance() + " Miles";
            Distance.setText(distance, EditText.BufferType.NORMAL);
        }
        //Set all the key listerners to Null so the Keyboard is not functional
        InputType.setKeyListener(null);
        ActivityType.setKeyListener(null);
        DateAndTime.setKeyListener(null);
        Duration.setKeyListener(null);
        Distance.setKeyListener(null);
        Calories.setKeyListener(null);
        HeartRate.setKeyListener(null);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_detailed_entryview, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //Listen to for the delete button
        if(item.getItemId() == R.id.deleteDetailedView){
            DatabaseReference ref = mDatabase.child("Users").child(mUserId).child("runs").child(""+entry.getId());
            ref.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    //This checks if the item exist in Firebase
                    //if it doesn't, meaning that it is only in the local Database
                    //the there is no error produced
                    if (dataSnapshot.hasChildren()) {
                        dataSnapshot.getRef().removeValue();
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

            //Delete the entry from the dataBase
            dataSource.deleteEntry(entry);
            //Close the Database
            dataSource.close();
            //update the Listview on fragment history since we changed one item
            //Let the user know the item has been deleted
            Toast.makeText(this, "Entry Deleted", Toast.LENGTH_SHORT).show();
            finish();
        }
        else if(item.getItemId() == R.id.openMap){
            //Check if this activity was created using Manual input
            //Or if this activity was created using the GPS or Automatic
            if(GPSorManual.equals("Manual Entry")){
                Toast.makeText(this, "Sorry but Map View is not\navailable for Manual Entry",
                        Toast.LENGTH_LONG).show();
            }
            else if ((!entry.getDistance().equals("0") || !entry.getDuration().equals("0secs"))){
                String mapArray = entry.getMapArray();
                mapArray = mapArray.substring(10, mapArray.length() - 2);
                Intent intent = new Intent(this, MapDetailedView.class);
                intent.putExtra("mapArray", mapArray);
                intent.putExtra("distance", entry.getDistance());
                intent.putExtra("duration", entry.getDuration());
                intent.putExtra("calories", entry.getCalories());
                intent.putExtra("type", entry.getActivityType());
                startActivity(intent);
            }
            else{
                Toast.makeText(this, "No GPS Data found for this Entry", Toast.LENGTH_LONG).show();
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //Close if the DataSource has not yet been close
        //by the delete action
        Fragment_history.upDateFragment();
        if(dataSource != null){
            dataSource.close();
        }
    }
}
