package io.github.httpsdmena105.myruns;

import android.app.Fragment;
import android.app.FragmentManager;
import android.support.v13.app.FragmentPagerAdapter;

import java.util.ArrayList;

/**
 * Created by davidmena on 1/12/18.
 *
 * This class is used by the Main Activity and it
 * allows us to have the tab-fragment layout
 *
 */

public class MyFragmentPageAdapter extends FragmentPagerAdapter {
    private ArrayList<Fragment> fragments;

    public MyFragmentPageAdapter(FragmentManager fm, ArrayList<Fragment> fragments){
        super(fm);
        this.fragments = fragments;
    }

    @Override
    public Fragment getItem(int pos){
        return fragments.get(pos);
    }

    @Override
    public int getCount(){
        return fragments.size();
    }

    @Override
    public CharSequence getPageTitle(int position){
        if(position == 0){
            return "START";
        }
        else if(position == 1){
            return "HISTORY";
        }
        else if(position == 2){
            return  "SETTINGS";
        }
        else{
            return null;
        }
    }
}
