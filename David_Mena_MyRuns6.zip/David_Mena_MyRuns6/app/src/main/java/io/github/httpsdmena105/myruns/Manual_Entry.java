package io.github.httpsdmena105.myruns;


import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

/**
 * Created by davidmena on 1/12/18.
 *
 * This Activity houses a list view and two buttons
 *
 * Each item of the list view opens a Dialog asks for user input
 * --The input does not save yet
 *
 */

public class Manual_Entry extends AppCompatActivity{
    final private static String TAG = "TES123";

    //Create new entry and DataSource items
    private Exersice_Entry entry = new Exersice_Entry();
    private ExcersiceEntry_DataSource dataSource = new ExcersiceEntry_DataSource(this);


    //ListView items
    static final String[] DATA = new String[] {
            "Date","Time", "Duration", "Distance",
            "Calories", "Heart Rate", "Comment"};

    //Activity Items
    //Used to read based on the position passed to the intent
    private String[] activityList = new String[] {
            "Running", "Walking", "Standing",
            "Cycling", "Hiking", "Downhill Skiing",
            "Cross-Country Skiing", "Snowboarding",
            "Skating", "Swimming", "Mountain Biking",
            "Wheelchair", "Elliptical", "Other"
    };

    //Input Type
    //Used to read based on the position passed to the intent
    private String[] inputList = new String[]{
            "Manual Entry", "GPS", "Automatic"
    };

    //Calendar item
    Calendar mDateAndTime = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manual_entry);

        //Define a new adapter for the Layout for input options
        ArrayAdapter<String> mAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, DATA);

        //Assign the adapter to ListView
        ListView listView = (ListView)findViewById(R.id.ManualListView);
        listView.setAdapter(mAdapter);

        //Get the Input and the actvity from Intent
        Intent intent = getIntent();
        //Position from the Array found in Array.xml
        int input = intent.getIntExtra("input", 0);
        int activity = intent.getIntExtra("activity", 0);
        String inputType = inputList[input];
        String activityType = activityList[activity];
        //Load the Strings into the entry
        entry.setActivityType(activityType);
        entry.setInputType(inputType);


        //Define the listener interface
        AdapterView.OnItemClickListener mListener= new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                //This shows the time when the Date is clicked
                if(((TextView) view).getText().equals("Date")){
                    DatePickerDialog.OnDateSetListener mDateListener = new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                            mDateAndTime.set(Calendar.YEAR, year);
                            mDateAndTime.set(Calendar.MONTH, month);
                            mDateAndTime.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                            updateDateandTime();
                            //Here is where you would call update or save
                        }
                    };

                    //Displays the current date
                    new DatePickerDialog(Manual_Entry.this, mDateListener,
                            mDateAndTime.get(Calendar.YEAR),
                            mDateAndTime.get(Calendar.MONTH),
                            mDateAndTime.get(Calendar.DAY_OF_MONTH)).show();

                }

                //Lets the user set the time
                else if(((TextView) view).getText().equals("Time")){
                    TimePickerDialog.OnTimeSetListener mTimeListetener = new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                            mDateAndTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                            mDateAndTime.set(Calendar.MINUTE, minute);
                            updateDateandTime();//Here is where you would update or save
                        }
                    };

                    //Diaplays the current Time
                    new TimePickerDialog(Manual_Entry.this, mTimeListetener,
                            mDateAndTime.get(Calendar.HOUR_OF_DAY),
                            mDateAndTime.get(Calendar.MINUTE), true).show();
                }

                //Number input dialog box
                else if(((TextView) view).getText().equals("Duration")){
                    DialogFragment newFragment = MyAlertDialogFragment
                            .newInstance(R.string.dialog_duration_tittle, R.string.number_pad);
                    newFragment.show(getFragmentManager(), "dialog");

                }
                //Number input dialog box
                else if(((TextView) view).getText().equals("Distance")){
                    DialogFragment newFragment = MyAlertDialogFragment
                            .newInstance(R.string.dialog_distance_tittle, R.string.number_pad);
                    newFragment.show(getFragmentManager(), "dialog");
                }
                //Number input dialog box
                else if(((TextView) view).getText().equals("Calories")){
                    DialogFragment newFragment = MyAlertDialogFragment
                            .newInstance(R.string.dialog_calories_tittle, R.string.number_pad);
                    newFragment.show(getFragmentManager(), "dialog");
                }
                //Number input dialog box
                else if(((TextView) view).getText().equals("Heart Rate")){
                    DialogFragment newFragment = MyAlertDialogFragment
                            .newInstance(R.string.dialog_Heart_tittle, R.string.number_pad);
                    newFragment.show(getFragmentManager(), "dialog");
                }
                //Full keyboard input dialog box with hints
                else if(((TextView) view).getText().equals("Comment")){
                    DialogFragment newFragment = MyAlertDialogFragment
                            .newInstance(R.string.dialog_Comment_tittle, R.string.QWERTY_keys);
                    newFragment.show(getFragmentManager(), "dialog");
                }
            }
        };

        //Get the ListView and wire the listener
        listView.setOnItemClickListener(mListener);
    }

    private void updateDateandTime() {
        String data = mDateAndTime.getTime().toString();
        String date1 = data.substring(0, 10);
        String date2 = data.substring(23);
        String date = date1.concat(date2);
        String time = data.substring(12, 23);
        //Set the Time and Date on the Entry
        entry.setDate(date);
        entry.setTime(time);
    }

    //Save the setings that were inputed in the dialog boxes
    public void onSaveManualClicked(View view){
        //Call the Async Task to write
        new WritingTask().execute();
        //Let the user know that the task has been completed
        Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_SHORT).show();
        finish();
    }

    //Closes the activity
    public void onCancelManualClicked(View view){
        Toast.makeText(getApplicationContext(), "Entry Discarded", Toast.LENGTH_SHORT).show();
        finish();
    }

    //if Ok is clicked on the dialog boxes we can do something here
    public void doPositiveClick(int type, String Result) {
        // The type is the title of the Dialog Frame
        // And the Result is what the user inputs
        // Load the result into the Entry after the
        // users clicks okay.
        switch (type){
            case R.string.dialog_duration_tittle:
                entry.setDuration(Result + "mins");
                break;
            case R.string.dialog_distance_tittle:
                entry.setDistance(Result);
                break;
            case R.string.dialog_calories_tittle:
                entry.setCalories(Result + " cal");
                break;
            case R.string.dialog_Heart_tittle:
                entry.setHeartRate(Result + " bpm");
                break;
            case R.string.dialog_Comment_tittle:
                entry.setComment(Result);
                break;
        }
    }

    //if cancel is clicked in the dialog boxes
    public void doNegativeClick() {
    }


    //****************************** NEW CLASS FOR THE ALERT DIALOG FRAME ****************//
    public static class MyAlertDialogFragment extends DialogFragment {

        //constructor
        public static MyAlertDialogFragment newInstance(int title, int keyboard) {
            MyAlertDialogFragment frag = new MyAlertDialogFragment();
            Bundle args = new Bundle();
            //The user can specify what the tittle of the dialog box and
            //What kind of keyboard they want the user to be able to use
            args.putInt("title", title);
            args.putInt("keyboard", keyboard);
            frag.setArguments(args);
            return frag;
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState){
            final int title = getArguments().getInt("title");
            int keyboard = getArguments().getInt("keyboard");
            //this is where the user types their input
            final EditText et;
            et = new EditText(getActivity());
            //what keyboard is chosen
            if(keyboard == R.string.number_pad) {
                et.setInputType(InputType.TYPE_CLASS_NUMBER);
            }
            //This one is only called when the comments is selected
            else{
                et.setInputType(InputType.TYPE_TEXT_VARIATION_SHORT_MESSAGE);
                et.setHint(R.string.dialog_comment_hints);
            }
            //Sets all the info and creates the dialog box and then send some info
            //back to the  activity based on what the user do after finishing their input
            return new AlertDialog.Builder(getActivity())
                    .setTitle(title)
                    .setView(et)
                    .setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,
                                                    int whichButton) {
                                    ((Manual_Entry) getActivity())
                                            .doPositiveClick(title ,et.getText().toString());
                                }
                            })
                    .setNegativeButton("CANCEL",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,
                                                    int whichButton) {
                                    ((Manual_Entry) getActivity())
                                            .doNegativeClick();
                                }
                            }).create();
        }
    }


//************* ASYNC-TASK for Writing Database **************//

    private class WritingTask extends AsyncTask<Void, Void, Void> {

        // A callback method executed on UI thread on starting the task
        @Override
        protected void onPreExecute() {
            //Starts the Database table
            dataSource.open();
        }

        @Override
        protected Void doInBackground(Void... params) {
            //Load the data from the entry item we we've created.
            dataSource.createEntry(entry.getDate(), entry.getTime(),
                    entry.getDuration(), entry.getDistance(), entry.getCalories(), entry.getHeartRate(),
                    entry.getComment(), entry.getInputType(), entry.getActivityType(), entry.getMapArray(),
                    entry.getId());
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }

        @Override
        protected void onPostExecute(Void result) {
            dataSource.close();
        }
    }
}