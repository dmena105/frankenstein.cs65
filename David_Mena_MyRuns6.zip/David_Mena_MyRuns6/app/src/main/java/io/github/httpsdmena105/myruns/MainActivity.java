package io.github.httpsdmena105.myruns;

import android.Manifest;
import android.app.Fragment;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    final private static String TAG = "TES123";


    //Set up the 3 Fragments
    Fragment START;
    Fragment HISTORY;
    Fragment SETTINGS;


    //Set up the main viewer and tabs
    ViewPager viewPager;
    TabLayout tabLayout;

    //Set up the fragment manager
    MyFragmentPageAdapter myFragmentPageAdapter;
    ArrayList<Fragment> fragments;

    //FireBase Elements
    private FirebaseAuth mFirebaseAuth;
    private FirebaseUser mFirebaseUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("MyRuns");

        // Initialize Firebase Auth and Database Reference
        mFirebaseAuth = FirebaseAuth.getInstance();
        mFirebaseUser = mFirebaseAuth.getCurrentUser();

        if (mFirebaseUser == null) {
            // Not logged in, launch the Log In activity
            loadLogInView();
        } else {
            //Permissions for camera and storage
            Util.checkPermissions(this);

            //Initilize all avaribles
            viewPager = findViewById(R.id.viewpager);
            tabLayout = findViewById(R.id.tab);

            //start the fragments
            START = new Fragment_start();
            HISTORY = new Fragment_history();
            SETTINGS = new Fragment_settings();

            //Initialize the Array of Fragments
            fragments = new ArrayList<Fragment>();

            //Add all the fragments to the fragment array
            fragments.add(START);
            fragments.add(HISTORY);
            fragments.add(SETTINGS);

            //The manager allows the tabs and fragments to work together
            myFragmentPageAdapter = new MyFragmentPageAdapter(getFragmentManager(), fragments);
            viewPager.setAdapter(myFragmentPageAdapter);
            tabLayout.setupWithViewPager(viewPager);
        }
    }

    //The log in page does not let the user get into the app without a valid
    //log in email and password.
    private void loadLogInView() {
        Intent intent = new Intent(this, LogInActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}
