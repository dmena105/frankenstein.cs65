package io.github.httpsdmena105.myruns;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ArrayBlockingQueue;

/**
 *
 * Created by davidmena on 2/3/18.
 *
 */

public class MapService extends Service implements LocationListener,
        SensorEventListener{
    final static String TAG = "TES123";

    public static final String CHANNEL_ID = "notification channel";
    private NotificationManager mNotificationManager;
    //Holds the list of Clients, which in our case should be 1
    private List<Messenger> mClients = new ArrayList<Messenger>();
    //These are the messages used to communicate
    public static final int MSG_REGISTER_CLIENT = 1;
    public static final int MSG_UNREGISTER_CLIENT = 2;
    public static final int MSG_SET_LATLNG_VALUE = 3;
    public static final int MSG_SET_ACTIVITY = 4;


    //This is used to count the Duration the service is running
    private Timer mTimer = new Timer();

    //Used for orientation change on Map

    //SENSOR SPECIFIC VARIABLES
    public static final int ACCELEROMETER_BUFFER_CAPACITY = 2048;
    public static final int ACCELEROMETER_BLOCK_CAPACITY = 64;

    private SensorManager mSensorManager;
    private Sensor mAccelerometer;

    private OnSensorChangedTask mAsyncTask;

    private static ArrayBlockingQueue<Double> mAccBuffer;

    private int Automatic;

    private class IncomingMessageHandler extends Handler{
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case MSG_REGISTER_CLIENT:
                    mClients.add(msg.replyTo);
                    Automatic = msg.getData().getInt("gps/auto");
                    if(Automatic == 0){
                        startSensorListeners();
                    }
                    break;
                case MSG_UNREGISTER_CLIENT:
                    mClients.remove(msg.replyTo);
                    if(Automatic == 0) {
                        stopSensors();
                    }
                    break;
                default:
                    super.handleMessage(msg);
            }
        }
    }

    private final Messenger mMessanger = new Messenger(new IncomingMessageHandler());


    @Override
    public void onCreate() {
        super.onCreate();
        showNotification();
        //This is so that the locationKeeps Updating
        initLocationManager();
        //This start counting until the Service Ends
        mTimer.scheduleAtFixedRate(new MyTask(), 0, 1000L);
    }

    //This Class initializes all the Sensor items when the activity is Automatic
    public void startSensorListeners(){
        mAccBuffer = new ArrayBlockingQueue<Double>(ACCELEROMETER_BUFFER_CAPACITY);

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);

        mSensorManager.registerListener(this, mAccelerometer,
                SensorManager.SENSOR_DELAY_FASTEST);

        mAsyncTask = new OnSensorChangedTask();
        mAsyncTask.execute();
    }

    public void stopSensors(){
        if (Automatic == 0) {
            mSensorManager.unregisterListener(this);
            mAsyncTask.cancel(true);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //This means that Android will kill the service when the app is killed
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mMessanger.getBinder();
    }

    @Override
    public boolean onUnbind(Intent intent) {return true;}

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        //This Will only get called if there is a listener active
        //and the listener will only be active if the activity is Automatic
        if(event.sensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION){
            double m = Math.sqrt(event.values[0] * event.values[0]
                    + event.values[1] * event.values[1] + event.values[2]
                    * event.values[2]);

            try {
                mAccBuffer.add(new Double(m));
            }catch (IllegalStateException e){
                ArrayBlockingQueue<Double> newBuff =
                        new ArrayBlockingQueue<Double>(mAccBuffer.size() * 2);

                mAccBuffer.drainTo(newBuff);
                mAccBuffer = newBuff;
                mAccBuffer.add(new Double(m));
            }
        }
    }


    private void showNotification(){
        NotificationChannel notificationChannel =
                new NotificationChannel(CHANNEL_ID, "channel name", NotificationManager.IMPORTANCE_DEFAULT);

        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, Map.class), 0);

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("MyRuns")
                .setContentText("Recording your path now")
                .setSmallIcon(R.drawable.icon)
                .setContentIntent(contentIntent);
        Notification notification = notificationBuilder.build();
        notification.flags = notification.flags | Notification.FLAG_ONGOING_EVENT;

        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        mNotificationManager.createNotificationChannel(notificationChannel);
        mNotificationManager.notify(0, notification);
    }


    ///////// WORKING WITH LOCATION AND UPDATING ExcersiceEntry Items //////////////

    public float mDistance = 0;
    double oldLat = 0;
    double oldLng = 0;

    public int mDuration = 0;
    public double AverageSpeed = 0;
    public double speed = 0;
    public double calories = 0;
    public double altitude = 0;

    //LOCATION LISTENER
    LocationManager locationManager;
    private void initLocationManager(){
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        String provider = locationManager.getBestProvider(criteria, true);
        Location location = locationManager.getLastKnownLocation(provider);

        if(location == null) {
            location = new Location("");
            location.setLatitude(43.703712);
            location.setLongitude(-72.288754);
        }

        onLocationChanged(location);
        locationManager.requestLocationUpdates(provider, 0, 0, this);

    }

    @Override
    public void onLocationChanged(Location location) {
        altitude = location.getAltitude();
        double lat = location.getLatitude();
        double lng = location.getLongitude();
        if(oldLat == 0 && oldLng == 0){
            oldLat = lat;
            oldLng = lng;
        }
        //Load a Variable with Distance
        setDistanceAndSpeed(oldLat, oldLng, lat, lng);
        //get Average Speed
        calculateAverageSpeed();
        //Calories
        calculateCalories();
        //update UI with new location
        sendUpdateLocationToMap(lat, lng);
    }
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {}
    @Override
    public void onProviderEnabled(String provider) {}
    @Override
    public void onProviderDisabled(String provider) {}

    private void sendUpdateLocationToMap(Double lat, Double lng){
        Iterator<Messenger> messengerIterable = mClients.iterator();

        while (messengerIterable.hasNext()){
            Messenger messenger = messengerIterable.next();
            try{
                Bundle bundle = new Bundle();
                bundle.putDouble("lat", lat);
                bundle.putDouble("lng", lng);
                bundle.putDouble("distance", mDistance);
                bundle.putInt("duration", mDuration);
                bundle.putDouble("averageSpeed", AverageSpeed);
                bundle.putDouble("speed", speed);
                bundle.putDouble("calories", calories);
                bundle.putDouble("altitude", altitude);
                Message msg_double = Message.obtain(null, MSG_SET_LATLNG_VALUE);
                msg_double.setData(bundle);
                messenger.send(msg_double);

            }catch (RemoteException e){
                mClients.remove(messenger);
            }
        }

    }

    public void setDistanceAndSpeed(Double oldLt, Double oldLg, Double newLat, Double newLng){
        float[] distanceArray = new float[1];
        Location.distanceBetween(oldLt, oldLg, newLat, newLng, distanceArray);
        double oldDis = mDistance;
        //This is the Distance in Meters
        mDistance = mDistance + distanceArray[0];
        //Meters per Second
        speed = mDistance - oldDis;
        //Log.d(TAG, "Distance " + mDistance);
        //Replace the old Variables
        oldLat = newLat;
        oldLng = newLng;
    }

    private class MyTask extends TimerTask {
        @Override
        public void run() {
//			Log.d(TAG, "T:MyTask():Timer doing work." + counter);
            try {
                //This is the Count in Seconds
                mDuration += 1;
                //Log.d(TAG, "Duration " + mDuration);

            } catch (Throwable t) { // you should always ultimately catch all
                // exceptions in timer tasks.
                Log.e(TAG, "Timer Tick Failed.", t);
            }
        }
    }

    private void calculateAverageSpeed(){
        //This returns in Meters / Second
        AverageSpeed = mDistance/mDuration;
    }

    private void calculateCalories(){
        // Calories = Distance / 13.5
        calories = mDistance / 13.5D;
    }

    private class OnSensorChangedTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            ArrayList<Double> vectorArray = new ArrayList<Double>(ACCELEROMETER_BLOCK_CAPACITY);
            int blockSize = 0;
            FFT fft = new FFT(ACCELEROMETER_BLOCK_CAPACITY);
            double[] accBlock = new double[ACCELEROMETER_BLOCK_CAPACITY];
            double[] re = accBlock;
            double[] im = new double[ACCELEROMETER_BLOCK_CAPACITY];

            double max = Double.MIN_VALUE;

            while (true) {
                try {

                    if (isCancelled ())
                    {
                        return null;
                    }

                    // Dumping buffer
                    accBlock[blockSize++] = mAccBuffer.take().doubleValue();

                    if (blockSize == ACCELEROMETER_BLOCK_CAPACITY) {
                        //System.out.println("Buffer size reached");
                        blockSize = 0;

                        // time = System.currentTimeMillis();
                        max = .0;
                        for (double val : accBlock) {
                            if (max < val) {
                                max = val;
                            }
                        }

                        fft.fft(re, im);

                        for (int i = 0; i < re.length; i++) {
                            double mag = Math.sqrt(re[i] * re[i] + im[i]
                                    * im[i]);
                            //inst.setValue(i, mag);
                            im[i] = .0; // Clear the field
                            vectorArray.add(mag);
                        }

                        // Append max after frequency component
                        vectorArray.add(max);

                        int classifiedValue = (int) WekaClassifier.classify(vectorArray.toArray());
                        sendUpdateActivityToMap(classifiedValue);
                        vectorArray.clear();

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }
    }

    private void sendUpdateActivityToMap(int currentActivity){
        Iterator<Messenger> messengerIterable = mClients.iterator();

        while (messengerIterable.hasNext()){
            Messenger messenger = messengerIterable.next();
            try{
                Bundle bundle = new Bundle();
                bundle.putInt("activity", currentActivity);
                Message msg_double = Message.obtain(null, MSG_SET_ACTIVITY);
                msg_double.setData(bundle);
                messenger.send(msg_double);

            }catch (RemoteException e){
                mClients.remove(messenger);
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mNotificationManager.cancelAll();
        if(locationManager != null){
            locationManager.removeUpdates(this);
        }
        if (mTimer != null) {
            mTimer.cancel();
        }
        mDuration = 0;
    }
}