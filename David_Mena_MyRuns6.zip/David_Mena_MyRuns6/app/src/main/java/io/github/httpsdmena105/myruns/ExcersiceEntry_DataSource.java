package io.github.httpsdmena105.myruns;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.google.android.gms.maps.GoogleMap;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by davidmena on 1/26/18.
 *
 * Connects the Entry to the DataBase.
 * The code interacts with this class
 * and this class interact with the database
 */

public class ExcersiceEntry_DataSource {
    final private static String TAG = "TES123";

    //Database fields
    private SQLiteDatabase database;
    private MySQLiteHelper dbHelper;
    private String[] allColumns = {MySQLiteHelper.COLUMN_ID, MySQLiteHelper.COLUMN_DATE,
                                    MySQLiteHelper.COLUMN_TIME, MySQLiteHelper.COLUMN_DURATION,
                                    MySQLiteHelper.COLUMN_DISTANCE, MySQLiteHelper.COLUMN_CALORIES,
                                    MySQLiteHelper.COLUMN_HEARTHRATE, MySQLiteHelper.COLUMN_COMMENT,
                                    MySQLiteHelper.COLUMN_INPUTTYPE, MySQLiteHelper.COLUMN_ACTIVITYTYPE,
                                    MySQLiteHelper.COLUMN_MAPARRAY};

    public ExcersiceEntry_DataSource (Context context){
        dbHelper = new MySQLiteHelper(context);
    }

    public void open() throws SQLException{
        database = dbHelper.getWritableDatabase();
    }

    public void close(){
        dbHelper.close();
    }

    public Exersice_Entry createEntry(String Date, String Time, String Duration, String Distance,
                                      String Calories, String HeartRate, String Comment,
                                      String Input, String Activity, String MapArray, long Id){


        //Row of Data
        ContentValues values = new ContentValues();
        //Add all the Data to the Row
        values.put(MySQLiteHelper.COLUMN_DATE, Date);
        values.put(MySQLiteHelper.COLUMN_TIME, Time);
        values.put(MySQLiteHelper.COLUMN_DURATION, Duration);
        values.put(MySQLiteHelper.COLUMN_DISTANCE, Distance);
        values.put(MySQLiteHelper.COLUMN_CALORIES, Calories);
        values.put(MySQLiteHelper.COLUMN_HEARTHRATE, HeartRate);
        values.put(MySQLiteHelper.COLUMN_COMMENT, Comment);
        values.put(MySQLiteHelper.COLUMN_INPUTTYPE, Input);
        values.put(MySQLiteHelper.COLUMN_ACTIVITYTYPE, Activity);
        values.put(MySQLiteHelper.COLUMN_MAPARRAY, MapArray);
        if(Id != -1){
            values.put(MySQLiteHelper.COLUMN_ID, Id);
        }


        //XD: For the second parameter, you need to supply the name of some column in your database
        // that allows NULL values, if there is one. If you supply such a column, then SQLite will
        // be able to handle the situation where you have an empty ContentValues
        // you are trying to insert into the database.
        //XD: http://stackoverflow.com/questions/2662927/android-sqlite-nullcolumnhack-parameter-in-insert-replace-methods

        long insertId = database.insert(MySQLiteHelper.TABLE_EXERCISE, null, values);
        Cursor cursor;

        cursor = database.query(MySQLiteHelper.TABLE_EXERCISE, allColumns,
                MySQLiteHelper.COLUMN_ID + " = " + insertId, null,
                null, null, null);

        cursor.moveToFirst();

        Exersice_Entry newEntry = cursorToExcersiceEntry(cursor);
        cursor.close();
        Log.d(TAG, "the entry has been created with ID: " + newEntry.getId());
        return newEntry;

    }

    public void deleteEntry(Exersice_Entry exersice_entry){
        long id = exersice_entry.getId();

        database.delete(MySQLiteHelper.TABLE_EXERCISE, MySQLiteHelper.COLUMN_ID +
        " = " + id, null);

    }

    public List<Exersice_Entry> getAllEntries(){
        List<Exersice_Entry> exersice_entries = new ArrayList<Exersice_Entry>();
        Cursor cursor = database.query(MySQLiteHelper.TABLE_EXERCISE,
                allColumns, null, null, null, null, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            //Work With the data to form the ArrayList<HashMap<String,String>>
            Exersice_Entry exersice_entry = cursorToExcersiceEntry(cursor);
            exersice_entries.add(exersice_entry);
            cursor.moveToNext();
        }

        cursor.close();
        return exersice_entries;
    }



    private Exersice_Entry cursorToExcersiceEntry(Cursor cursor){
        Exersice_Entry exersice_entry = new Exersice_Entry();
        exersice_entry.setId(cursor.getLong(0));
        exersice_entry.setDate(cursor.getString(1));
        exersice_entry.setTime(cursor.getString(2));
        exersice_entry.setDuration(cursor.getString(3));
        exersice_entry.setDistance(cursor.getString(4));
        exersice_entry.setCalories(cursor.getString(5));
        exersice_entry.setHeartRate(cursor.getString(6));
        exersice_entry.setComment(cursor.getString(7));
        exersice_entry.setInputType(cursor.getString(8));
        exersice_entry.setActivityType(cursor.getString(9));
        exersice_entry.setMapArray(cursor.getString(10));
        return exersice_entry;

    }


}
