package io.github.httpsdmena105.myruns;

import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by davidmena on 1/26/18.
 *
 * This is an Object class that defines an Excercise
 * Entry.
 *
 * It has all the components of a Entry
 */

public class Exersice_Entry {
    final private static String TAG = "TES123";

    private Calendar mDateAndTime = Calendar.getInstance();
    private String data = mDateAndTime.getTime().toString();
    private String date1 = data.substring(0, 10);
    private String date2 = data.substring(23);
    private String date = date1.concat(date2);
    private String time = data.substring(11, 23);


    private long id = -1; //Row Number in the db
    private String InputType;
    private String ActivityType;
    private String Date = date;
    private String Time = time;
    private String Duration = "0 mins";
    private String Distance = "0";
    private String Calories = "0 cal";
    private String HeartRate = "0 bpm";
    private String Comment = "No Comment";
    private String MapArray = "Empty";


    public long getId(){
        return id;
    }

    public void setId(long id){
        this.id = id;
    }

    //INPUT TYPE
    public void setInputType(String inputType){
        this.InputType = inputType;
    }

    public String getInputType(){
        return InputType;
    }

    //ACtivity Type
    public void setActivityType(String activityType){
        this.ActivityType = activityType;
    }

    public String getActivityType(){
        return ActivityType;
    }

    //DATE
    public String getDate(){
        return Date;
    }

    public void setDate(String date){
        this.Date = date;
    }

    //TIME
    public String getTime(){
        return Time;
    }

    public void setTime(String time){
        this.Time = time;
    }

    //DURATION
    public String getDuration(){
        return Duration;
    }

    public void setDuration(String duration){
        this.Duration = duration;
    }

    //DISTANCE
    public String getDistance(){
        return Distance;
    }

    public void setDistance(String distance){
        this.Distance = distance;
    }

    //CALORIES
    public String getCalories(){
        return Calories;
    }

    public void setCalories(String calories){
        this.Calories = calories;
    }

    //HEART RATE
    public String getHeartRate(){
        return HeartRate;
    }

    public void setHeartRate(String heartRate){
        this.HeartRate = heartRate;
    }

    //COMMENT
    public String getComment(){
        return Comment;
    }

    public void setComment(String comment){
        this.Comment = comment;
    }

    public void setMapArray(String array){
        this.MapArray = array;
    }

    public String getMapArray(){
        return MapArray;
    }

    @Override
    public String toString(){
        return Date + Time + Duration + Distance + Calories + HeartRate + Comment;
    }
}
