package io.github.httpsdmena105.myruns;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.google.android.gms.maps.GoogleMap;

/**
 *
 * Created by davidmena on 1/26/18.
 *
 *
 */

public class MySQLiteHelper extends SQLiteOpenHelper{

    //Name of the table in theDataBase
    public static final String TABLE_EXERCISE = "Excersice_data";
    //First Column
    public static final String COLUMN_ID = "_id";
    //Second Column
    public static final String COLUMN_DATE = "_date";
    //Third Column
    public static final String COLUMN_TIME = "_time";
    //Fourth Column
    public static final String COLUMN_DURATION = "_duration";
    //Fifth Column
    public static final String COLUMN_DISTANCE = "_distance";
    //Sixth Column
    public static final String COLUMN_CALORIES = "_calories";
    //Seventh Column
    public static final String COLUMN_HEARTHRATE = "_hearth";
    //Eight Column
    public static final String COLUMN_COMMENT = "_comment";
    //Ninth Column
    public static final String COLUMN_INPUTTYPE = "_input";
    //Tenth Column
    public static final String COLUMN_ACTIVITYTYPE = "_activity";
    //Evelenth Column
    public static final String COLUMN_MAPARRAY ="_maparray";



    //Name of DataBase
    public static final String DATABASE_NAME = "Excersice_data.db";
    //Version
    public static final int DATABASE_VERSION = 1;

    //	//XD: SQL command - create table table_name(col1, col1 property, col2, col2 property);
    private static final String DATABASE_CREATE = "create table "
            + TABLE_EXERCISE + "(" +
            COLUMN_ID + " integer primary key autoincrement, " +
            COLUMN_DATE + " text, " +
            COLUMN_TIME + " text, " +
            COLUMN_DURATION + " text, " +
            COLUMN_DISTANCE + " text, " +
            COLUMN_CALORIES + " text, " +
            COLUMN_HEARTHRATE + " text, " +
            COLUMN_COMMENT + " text, " +
            COLUMN_INPUTTYPE + " text, " +
            COLUMN_ACTIVITYTYPE + " text, " +
            COLUMN_MAPARRAY + " text);";

    public MySQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database){
        database.execSQL(DATABASE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EXERCISE);
        onCreate(db);
    }





}
